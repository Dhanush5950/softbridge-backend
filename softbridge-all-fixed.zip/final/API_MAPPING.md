# SoftBridge — Frontend ↔ Backend API Mapping

**Backend base URL:** `http://localhost:8080/api`  
**Auth:** Bearer JWT token in `Authorization` header

---

## ✅ Auth Endpoints

| Service Method | HTTP | Path | Backend Controller |
|---|---|---|---|
| `authService.login()` | POST | `/auth/login` | `AuthController` |
| `authService.register()` | POST | `/auth/register` | `AuthController` |
| `authService.logout()` | POST | `/auth/logout` | `AuthController` |

### AuthResponse shape (returned on login/register):
```json
{
  "success": true,
  "data": {
    "accessToken": "eyJ...",
    "tokenType": "Bearer",
    "expiresIn": 86400000,
    "userId": 1,
    "firstName": "Jane",
    "lastName": "Doe",
    "email": "jane@example.com",
    "company": "ACME",
    "role": "CLIENT",
    "createdAt": "2024-01-01T00:00:00"
  }
}
```

---

## ✅ Profile Endpoints (any authenticated user)

| Service Method | HTTP | Path | Backend Controller |
|---|---|---|---|
| `authService.getProfile()` | GET | `/users/me` | `UserController` |
| `authService.updateProfile()` | PUT | `/users/me` | `UserController` |
| `authService.changePassword()` | PATCH | `/users/me/password` | `UserController` |

---

## ✅ Requirement Endpoints

### Client
| Service Method | HTTP | Path |
|---|---|---|
| `requirementService.submit()` | POST | `/requirements` |
| `requirementService.getMyRequirements()` | GET | `/requirements/my?page=0&size=10` |
| `requirementService.getMyRequirementById(id)` | GET | `/requirements/my/{id}` |

### Admin
| Service Method | HTTP | Path |
|---|---|---|
| `requirementService.getAll()` | GET | `/requirements?page=0&size=10&status=&query=` |
| `requirementService.getById(id)` | GET | `/requirements/{id}` |
| `requirementService.update(id, data)` | PUT | `/requirements/{id}` |
| `requirementService.makeDecision(id, status)` | PATCH | `/requirements/{id}/decision` |
| `requirementService.delete(id)` | DELETE | `/requirements/{id}` |
| `requirementService.getStats()` | GET | `/requirements/stats` |

### RequirementRequest body (POST /requirements):
```json
{
  "projectName": "My App",
  "projectType": "Web Application",
  "description": "...",
  "timeline": "3–6 Months",
  "frontendStack": ["React", "Tailwind CSS"],
  "backendStack": ["Spring Boot"],
  "databaseStack": ["MySQL"],
  "deploymentStack": ["AWS"],
  "budget": "$15,000 – $50,000",
  "teamSize": "3–5 Developers",
  "specialFeatures": "...",
  "priority": "MEDIUM"
}
```

### DecisionRequest body (PATCH /requirements/{id}/decision):
```json
{
  "status": "INHOUSE",
  "adminNotes": "We have capacity for this project"
}
```
> **Valid status values:** `INHOUSE` or `OUTSOURCE` (not PENDING)

---

## ✅ Admin User Endpoints

| Service Method | HTTP | Path |
|---|---|---|
| `userService.getAll()` | GET | `/admin/users?query=` |
| `userService.getById(id)` | GET | `/admin/users/{id}` |
| `userService.update(id, data)` | PUT | `/admin/users/{id}` |
| `userService.toggleStatus(id)` | PATCH | `/admin/users/{id}/toggle-active` |
| `userService.delete(id)` | DELETE | `/admin/users/{id}` |

> **Create user:** Use `authService.register()` — no dedicated `POST /users` endpoint.

---

## ⚠️ Mismatches Fixed

| Old (wrong) | New (correct) | Reason |
|---|---|---|
| `GET /auth/me` | `GET /users/me` | Profile is on UserController |
| `PUT /auth/profile` | `PUT /users/me` | Same above |
| `PUT /auth/change-password` | `PATCH /users/me/password` | PATCH, not PUT |
| `GET /users` | `GET /admin/users` | Admin route prefix |
| `GET /users/{id}` | `GET /admin/users/{id}` | Admin route prefix |
| `PUT /users/{id}` | `PUT /admin/users/{id}` | Admin route prefix |
| `DELETE /users/{id}` | `DELETE /admin/users/{id}` | Admin route prefix |
| `PATCH /users/{id}/toggle-status` | `PATCH /admin/users/{id}/toggle-active` | Different path + endpoint name |
| `PATCH /requirements/{id}/status` | `PATCH /requirements/{id}/decision` | Different endpoint name |
| `response.data.token` | `response.data.data.accessToken` | ApiResponse wrapper |
| `response.data.user` | Build from `response.data.data` fields | No nested user object |

---

## 🔴 Not Yet in Backend (Future Scope)

| Feature | Frontend Service | Status |
|---|---|---|
| Password reset | `authService.forgotPassword/resetPassword` | Future sprint |
| Email verification | `authService.verifyEmail` | Future sprint |
| Token refresh | `authService.refreshToken` | Future sprint |
| File uploads | `requirementService.uploadFile` | Future sprint |
| Comments | `requirementService.addComment/getComments` | Future sprint |
| Assign developer | `requirementService.assign` | Future sprint |
| Export report | `requirementService.exportReport` | Future sprint |
| Analytics | `analyticsService.*` | Future sprint |
| Notifications | `notificationService.*` | Future sprint (UI uses in-memory) |
| Create user (admin) | `userService.create` | Use `authService.register` for now |

---

## Backend Status Enums

### RequirementStatus:
- `PENDING` — submitted, awaiting admin decision
- `INHOUSE` — admin decided to build internally
- `OUTSOURCE` — admin decided to route to external partner

### Priority:
- `LOW` | `MEDIUM` | `HIGH`

### Role:
- `CLIENT` | `ADMIN` | `DEVELOPER`
