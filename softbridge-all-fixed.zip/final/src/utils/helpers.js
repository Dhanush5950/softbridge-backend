import { format, formatDistanceToNow, parseISO } from "date-fns";

// ── Date Formatting ───────────────────────────────────────────────────────────
export const formatDate = (date) => {
  if (!date) return "—";
  try {
    return format(
      typeof date === "string" ? parseISO(date) : date,
      "MMM dd, yyyy"
    );
  } catch {
    return "—";
  }
};

export const formatDateTime = (date) => {
  if (!date) return "—";
  try {
    return format(
      typeof date === "string" ? parseISO(date) : date,
      "MMM dd, yyyy • HH:mm"
    );
  } catch {
    return "—";
  }
};

export const timeAgo = (date) => {
  if (!date) return "—";
  try {
    return formatDistanceToNow(
      typeof date === "string" ? parseISO(date) : date,
      { addSuffix: true }
    );
  } catch {
    return "—";
  }
};

// ── Currency ──────────────────────────────────────────────────────────────────
export const formatCurrency = (amount, currency = "USD") => {
  if (amount == null) return "—";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

// ── File Size ─────────────────────────────────────────────────────────────────
export const formatFileSize = (bytes) => {
  if (!bytes) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
};

// ── Text ──────────────────────────────────────────────────────────────────────
export const truncate = (text, maxLength = 100) => {
  if (!text) return "";
  return text.length > maxLength
    ? text.substring(0, maxLength) + "..."
    : text;
};

export const getInitials = (name) => {
  if (!name) return "?";
  return name
    .split(" ")
    .map((word) => word[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
};

// ── Status Config ─────────────────────────────────────────────────────────────
/**
 * Maps backend RequirementStatus enum values to UI display config.
 *
 * Backend enums (RequirementStatus.java):
 *   PENDING   — submitted, awaiting admin decision
 *   INHOUSE   — admin decided to build internally
 *   OUTSOURCE — admin decided to route to external partner
 *
 * ⚠️  Frontend had extra statuses (UNDER_REVIEW, APPROVED, REJECTED,
 *     IN_PROGRESS, COMPLETED) that do NOT exist in the backend.
 *     These are kept here as display-only aliases so existing UI components
 *     don't break, but the actual backend only sends PENDING/INHOUSE/OUTSOURCE.
 */
export const getStatusConfig = (status) => {
  const configs = {
    // ── Backend statuses ──────────────────────────────────────────────────
    PENDING: {
      label: "⏳ Pending",
      className: "badge-pending",
      dot: "bg-amber-400",
      color: "#f59e0b",
      description: "Submitted, awaiting admin decision",
    },
    INHOUSE: {
      label: "🏠 In-House",
      className: "badge-inhouse",
      dot: "bg-emerald-400",
      color: "#10b981",
      description: "Approved — building internally",
    },
    OUTSOURCE: {
      label: "🌐 Outsourced",
      className: "badge-outsource",
      dot: "bg-orange-400",
      color: "#f97316",
      description: "Routed to external partner",
    },

    // ── Legacy / future statuses (not in backend yet) ─────────────────────
    // Kept for UI compatibility. Remove when backend is extended.
    UNDER_REVIEW: {
      label: "Under Review",
      className: "badge-review",
      dot: "bg-brand-400",
      color: "#4c6ef5",
    },
    APPROVED: {
      label: "Approved",
      className: "badge-approved",
      dot: "bg-emerald-400",
      color: "#10b981",
    },
    REJECTED: {
      label: "Rejected",
      className: "badge-rejected",
      dot: "bg-rose-400",
      color: "#f43f5e",
    },
    IN_PROGRESS: {
      label: "In Progress",
      className: "badge-inprogress",
      dot: "bg-violet-400",
      color: "#7c3aed",
    },
    COMPLETED: {
      label: "Completed",
      className: "badge-completed",
      dot: "bg-cyan-400",
      color: "#06b6d4",
    },
  };

  return configs[status] || configs.PENDING;
};

// ── Priority Config ───────────────────────────────────────────────────────────
/**
 * Backend Priority enum: LOW | MEDIUM | HIGH
 * ⚠️  CRITICAL does not exist in backend — removed from the list.
 */
export const getPriorityConfig = (priority) => {
  const configs = {
    LOW: {
      label: "🟢 Low",
      className: "text-emerald-400",
      color: "#10b981",
    },
    MEDIUM: {
      label: "🟡 Medium",
      className: "text-amber-400",
      color: "#f59e0b",
    },
    HIGH: {
      label: "🔴 High",
      className: "text-rose-400",
      color: "#f43f5e",
    },
  };
  return configs[priority] || configs.MEDIUM;
};

// ── Tech Stacks ───────────────────────────────────────────────────────────────
// Matches the tag options in submit.html / SubmitRequirement.jsx
export const TECH_STACKS = {
  frontend: [
    "React", "Vue.js", "Angular", "Next.js", "Svelte",
    "HTML/CSS/JS", "React Native", "Flutter", "Tailwind CSS",
  ],
  backend: [
    "Spring Boot", "Node.js", "Express.js", "Django", "FastAPI",
    "Laravel", "Ruby on Rails", "GraphQL", ".NET / C#",
  ],
  database: [
    "MySQL", "PostgreSQL", "MongoDB", "Redis", "SQLite",
    "Firebase", "Supabase", "DynamoDB",
  ],
  deployment: [
    "AWS", "Google Cloud", "Azure", "Vercel", "Render.com",
    "Heroku", "Docker", "Kubernetes", "DigitalOcean",
  ],
};

// ── Project Types ─────────────────────────────────────────────────────────────
// Matches the options in the submit form
export const PROJECT_TYPES = [
  "Web Application",
  "Mobile Application",
  "REST API / Backend",
  "E-Commerce Platform",
  "SaaS Product",
  "Desktop Application",
  "Data Analytics Dashboard",
  "Other",
];

// ── Timeline Options ──────────────────────────────────────────────────────────
export const TIMELINE_OPTIONS = [
  "1–2 Weeks (Urgent)",
  "1 Month",
  "2–3 Months",
  "3–6 Months",
  "6–12 Months",
  "12+ Months",
];

// ── Budget Options ────────────────────────────────────────────────────────────
export const BUDGET_OPTIONS = [
  "Under $5,000",
  "$5,000 – $15,000",
  "$15,000 – $50,000",
  "$50,000 – $100,000",
  "$100,000+",
  "To be discussed",
];

// ── Priority Levels (backend enum) ────────────────────────────────────────────
// ⚠️  Only LOW, MEDIUM, HIGH exist in backend Priority.java
export const PRIORITY_LEVELS = ["LOW", "MEDIUM", "HIGH"];

// ── Team Size Options ─────────────────────────────────────────────────────────
export const TEAM_SIZE_OPTIONS = [
  "1–2 Developers",
  "3–5 Developers",
  "6–10 Developers",
  "10+ Developers",
  "No Preference",
];

// ── Validation ────────────────────────────────────────────────────────────────
export const validateEmail = (email) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

// Backend requires min 6 characters (RegisterRequest @Size(min=6))
export const validatePassword = (password) => password.length >= 6;

export const validatePhone = (phone) =>
  /^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/.test(phone);

// ── Avatar Colors ─────────────────────────────────────────────────────────────
export const AVATAR_COLORS = [
  "from-brand-500 to-violet-600",
  "from-cyan-500 to-brand-600",
  "from-rose-500 to-amber-500",
  "from-emerald-500 to-cyan-500",
  "from-violet-500 to-rose-500",
  "from-amber-500 to-rose-400",
];

export const getAvatarColor = (name) => {
  if (!name) return AVATAR_COLORS[0];
  const idx = name.charCodeAt(0) % AVATAR_COLORS.length;
  return AVATAR_COLORS[idx];
};

// ── Role Labels ───────────────────────────────────────────────────────────────
// Backend Role enum: CLIENT | ADMIN | DEVELOPER
export const getRoleLabel = (role) => {
  const labels = {
    CLIENT:    "Client",
    ADMIN:     "Admin",
    DEVELOPER: "Developer",
  };
  return labels[role] || role;
};
