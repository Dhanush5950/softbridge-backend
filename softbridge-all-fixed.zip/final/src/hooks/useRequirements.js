import { useState, useEffect, useCallback } from "react";
import { requirementService } from "../services/requirementService";
import toast from "react-hot-toast";

// ── Debounce hook ─────────────────────────────────────────────────────────────
export const useDebounce = (value, delay = 300) => {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
};

// ── Pagination hook ───────────────────────────────────────────────────────────
export const usePagination = (totalItems, itemsPerPage = 10) => {
  const [currentPage, setCurrentPage] = useState(0); // backend is 0-indexed

  const totalPages = Math.ceil(totalItems / itemsPerPage);

  const goToPage = useCallback(
    (page) => setCurrentPage(Math.min(Math.max(0, page), totalPages - 1)),
    [totalPages]
  );

  const nextPage = () => goToPage(currentPage + 1);
  const prevPage = () => goToPage(currentPage - 1);

  return {
    currentPage,
    totalPages,
    goToPage,
    nextPage,
    prevPage,
    isFirstPage: currentPage === 0,
    isLastPage:  currentPage >= totalPages - 1,
  };
};

// ── Admin: All Requirements hook ──────────────────────────────────────────────
/**
 * Fetches all requirements (ADMIN only).
 *
 * Backend: GET /requirements?page=0&size=10&status=PENDING&query=search
 * Returns: ApiResponse<PageResponse<RequirementResponse>>
 *
 * PageResponse shape:
 * { content[], page, size, totalElements, totalPages, first, last }
 *
 * RequirementResponse shape:
 * { id, clientId, clientName, clientEmail, company, projectName, projectType,
 *   description, timeline, frontendStack[], backendStack[], databaseStack[],
 *   deploymentStack[], budget, teamSize, specialFeatures, priority,
 *   status (PENDING|INHOUSE|OUTSOURCE), adminNotes, submittedAt, updatedAt, decidedAt }
 */
export const useRequirements = (filters = {}) => {
  const [data, setData]       = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);
  const [total, setTotal]     = useState(0);
  const [pageInfo, setPageInfo] = useState({});

  const fetchRequirements = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await requirementService.getAll(filters);

      /**
       * Backend wraps everything in ApiResponse:
       * response.data = { success, message, data: PageResponse, timestamp }
       * response.data.data = { content, page, size, totalElements, totalPages, ... }
       */
      const pageData = response.data.data;
      setData(pageData.content || []);
      setTotal(pageData.totalElements || 0);
      setPageInfo({
        page:       pageData.page,
        size:       pageData.size,
        totalPages: pageData.totalPages,
        first:      pageData.first,
        last:       pageData.last,
      });
    } catch (err) {
      const message = err?.response?.data?.message || err.message;
      setError(message);
      toast.error("Failed to load requirements");
      // Fallback to empty so UI doesn't crash
      setData([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  }, [JSON.stringify(filters)]);

  useEffect(() => {
    fetchRequirements();
  }, [fetchRequirements]);

  return { data, loading, error, total, pageInfo, refetch: fetchRequirements };
};

// ── Client: My Requirements hook ──────────────────────────────────────────────
/**
 * Fetches only the current client's requirements.
 * Backend: GET /requirements/my?page=0&size=10
 */
export const useMyRequirements = (filters = {}) => {
  const [data, setData]       = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);
  const [total, setTotal]     = useState(0);

  const fetchRequirements = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await requirementService.getMyRequirements(filters);
      const pageData = response.data.data;
      setData(pageData.content || []);
      setTotal(pageData.totalElements || 0);
    } catch (err) {
      const message = err?.response?.data?.message || err.message;
      setError(message);
      setData([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  }, [JSON.stringify(filters)]);

  useEffect(() => {
    fetchRequirements();
  }, [fetchRequirements]);

  return { data, loading, error, total, refetch: fetchRequirements };
};

// ── Dashboard Stats hook ──────────────────────────────────────────────────────
/**
 * Fetches dashboard statistics (ADMIN only).
 * Backend: GET /requirements/stats
 *
 * DashboardStatsResponse:
 * { totalRequirements, pendingCount, inhouseCount, outsourceCount,
 *   totalUsers, clientCount, developerCount, byProjectType{}, byStatus{} }
 */
export const useDashboardStats = () => {
  const [stats, setStats]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  const fetchStats = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await requirementService.getStats();
      setStats(response.data.data);
    } catch (err) {
      const message = err?.response?.data?.message || err.message;
      setError(message);
      setStats(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  return { stats, loading, error, refetch: fetchStats };
};

// ── Local storage hook ────────────────────────────────────────────────────────
export const useLocalStorage = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });

  const setValue = useCallback(
    (value) => {
      try {
        const valueToStore =
          value instanceof Function ? value(storedValue) : value;
        setStoredValue(valueToStore);
        localStorage.setItem(key, JSON.stringify(valueToStore));
      } catch (error) {
        console.error(error);
      }
    },
    [key, storedValue]
  );

  return [storedValue, setValue];
};
