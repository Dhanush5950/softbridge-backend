/**
 * src/hooks/index.js
 * Central export for all custom hooks.
 *
 * Usage:
 *   import { useRequirements, useDashboardStats, useDebounce } from "../hooks";
 */

export {
  useRequirements,    // Admin: GET /requirements (paginated + filtered)
  useMyRequirements,  // Client: GET /requirements/my
  useDashboardStats,  // Admin: GET /requirements/stats
  usePagination,      // 0-indexed pagination (matches Spring Page)
  useDebounce,        // debounce any value (default 300ms)
  useLocalStorage,    // persist state in localStorage
} from "./useRequirements";

export {
  useClickOutside,    // detect click outside a ref element
} from "./useClickOutside";
