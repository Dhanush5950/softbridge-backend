import api from "./api";

/**
 * userService — maps to backend UserController
 *
 * Backend endpoints available:
 *
 * Profile (any authenticated user):
 *   GET    /users/me
 *   PUT    /users/me
 *   PATCH  /users/me/password
 *
 * Admin user management:
 *   GET    /admin/users?query=
 *   GET    /admin/users/{id}
 *   PUT    /admin/users/{id}
 *   PATCH  /admin/users/{id}/toggle-active
 *   DELETE /admin/users/{id}
 *
 * NOT in backend yet (future scope):
 *   POST /users          → create user (admin can register via /auth/register)
 *   GET  /users/stats    → separate user stats endpoint
 *   GET  /users/developers → filter by DEVELOPER role
 *   /analytics/*         → analytics endpoints
 *   /notifications/*     → notification endpoints
 */

// ── Profile Service ───────────────────────────────────────────────────────────
export const profileService = {
  /**
   * GET /users/me
   * Returns UserResponse for the logged-in user
   */
  getMe() {
    return api.get("/users/me");
  },

  /**
   * PUT /users/me
   * Body: UpdateUserRequest { firstName?, lastName?, email?, company?, phone? }
   */
  updateMe(data) {
    return api.put("/users/me", data);
  },

  /**
   * PATCH /users/me/password
   * Body: ChangePasswordRequest { currentPassword, newPassword, confirmPassword }
   */
  changePassword(data) {
    return api.patch("/users/me/password", data);
  },
};

// ── Admin User Service ────────────────────────────────────────────────────────
export const userService = {
  /**
   * GET /admin/users?query=searchterm
   * Returns List<UserResponse>
   *
   * ⚠️  Frontend was calling /users — FIXED to /admin/users
   */
  getAll(params = {}) {
    return api.get("/admin/users", { params });
  },

  /**
   * GET /admin/users/{id}
   * ⚠️  Frontend was calling /users/{id} — FIXED to /admin/users/{id}
   */
  getById(id) {
    return api.get(`/admin/users/${id}`);
  },

  /**
   * PUT /admin/users/{id}
   * Body: UpdateUserRequest
   * ⚠️  Frontend was calling /users/{id} — FIXED to /admin/users/{id}
   */
  update(id, data) {
    return api.put(`/admin/users/${id}`, data);
  },

  /**
   * PATCH /admin/users/{id}/toggle-active
   * Toggles user active/inactive status
   * ⚠️  Frontend was calling /users/{id}/toggle-status — FIXED to /toggle-active
   */
  toggleStatus(id) {
    return api.patch(`/admin/users/${id}/toggle-active`);
  },

  /**
   * DELETE /admin/users/{id}
   * ⚠️  Frontend was calling /users/{id} — FIXED to /admin/users/{id}
   */
  delete(id) {
    return api.delete(`/admin/users/${id}`);
  },

  /**
   * Workaround: get developers by filtering all users by role.
   * Backend has UserRepository.findByRole(Role.DEVELOPER) but no dedicated endpoint.
   * We fetch all users and filter client-side until a dedicated endpoint is added.
   *
   * Future: GET /admin/users?role=DEVELOPER
   */
  async getDevelopers() {
    const response = await api.get("/admin/users");
    const users = response.data?.data || [];
    return {
      ...response,
      data: {
        ...response.data,
        data: users.filter((u) => u.role === "DEVELOPER"),
      },
    };
  },

  /**
   * User stats — derived from /requirements/stats which includes:
   * totalUsers, clientCount, developerCount
   * Use requirementService.getStats() for this until a dedicated endpoint is added.
   *
   * Future: GET /admin/users/stats
   */
  getStats() {
    return api.get("/requirements/stats");
  },

  /**
   * Admin can create users by calling the register endpoint.
   * POST /auth/register
   * Body: { firstName, lastName, email, password, company?, phone?, role }
   *
   * ⚠️  There is no POST /users endpoint — use authService.register() instead.
   */
};

// ── Analytics Service ─────────────────────────────────────────────────────────
// NOTE: No analytics endpoints exist in the backend yet.
// All data is derived from /requirements/stats for now.
export const analyticsService = {
  /**
   * GET /requirements/stats
   * Returns DashboardStatsResponse which includes:
   *   totalRequirements, pendingCount, inhouseCount, outsourceCount,
   *   totalUsers, clientCount, developerCount, byProjectType{}, byStatus{}
   *
   * This is used as the analytics dashboard data source until dedicated
   * analytics endpoints are built.
   */
  getDashboard() {
    return api.get("/requirements/stats");
  },

  // Future scope — not in backend yet:
  // getRequirementTrends(period) → GET /analytics/requirements?period=
  // getTechStackUsage()          → GET /analytics/tech-stacks
  // getBudgetAnalysis()          → GET /analytics/budget
  // getClientActivity()          → GET /analytics/client-activity
};

// ── Notification Service ──────────────────────────────────────────────────────
// NOTE: No notification endpoints exist in the backend yet.
// Notifications are handled client-side via NotificationContext (in-memory).
// This service is a stub ready for when the backend implements it.
export const notificationService = {
  // Future scope — not in backend yet:
  // getAll()                  → GET    /notifications
  // markRead(id)              → PATCH  /notifications/{id}/read
  // markAllRead()             → PATCH  /notifications/read-all
  // delete(id)                → DELETE /notifications/{id}
  // getPreferences()          → GET    /notifications/preferences
  // updatePreferences(data)   → PUT    /notifications/preferences
};
