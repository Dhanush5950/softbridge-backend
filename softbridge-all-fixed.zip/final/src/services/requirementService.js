import api from "./api";

/**
 * requirementService — maps to backend RequirementController (/api/requirements/*)
 *
 * Backend endpoints available:
 *   POST   /requirements                      → submit (CLIENT)
 *   GET    /requirements/my                   → getMyRequirements (CLIENT)
 *   GET    /requirements/my/{id}              → getMyRequirementById (CLIENT)
 *   GET    /requirements                      → getAll with ?status=&query= (ADMIN)
 *   GET    /requirements/{id}                 → getById (ADMIN + CLIENT)
 *   PUT    /requirements/{id}                 → update (ADMIN)
 *   PATCH  /requirements/{id}/decision        → makeDecision (ADMIN)
 *   DELETE /requirements/{id}                 → delete (ADMIN)
 *   GET    /requirements/stats                → getDashboardStats (ADMIN)
 *
 * NOT in backend yet (future scope):
 *   file uploads, comments, export, assign
 */
export const requirementService = {

  // ── CLIENT Endpoints ──────────────────────────────────────────────────────

  /**
   * POST /requirements
   * Body: RequirementRequest {
   *   projectName*, projectType*, description*,
   *   timeline, frontendStack[], backendStack[], databaseStack[],
   *   deploymentStack[], budget, teamSize, specialFeatures, priority
   * }
   * Returns: ApiResponse<RequirementResponse>
   */
  submit(data) {
    return api.post("/requirements", data);
  },

  /**
   * GET /requirements/my?page=0&size=10
   * Returns: ApiResponse<PageResponse<RequirementResponse>>
   */
  getMyRequirements(params = {}) {
    return api.get("/requirements/my", { params });
  },

  /**
   * GET /requirements/my/{id}
   * Returns the requirement only if it belongs to the current client
   */
  getMyRequirementById(id) {
    return api.get(`/requirements/my/${id}`);
  },

  // ── ADMIN + CLIENT Shared ─────────────────────────────────────────────────

  /**
   * GET /requirements/{id}
   * Accessible by ADMIN and CLIENT (client sees any req, admin sees all)
   */
  getById(id) {
    return api.get(`/requirements/${id}`);
  },

  // ── ADMIN Endpoints ───────────────────────────────────────────────────────

  /**
   * GET /requirements?page=0&size=10&status=PENDING&query=searchterm
   * Returns: ApiResponse<PageResponse<RequirementResponse>>
   */
  getAll(params = {}) {
    return api.get("/requirements", { params });
  },

  /**
   * PUT /requirements/{id}
   * Body: UpdateRequirementRequest — all fields optional (partial update)
   * Returns: ApiResponse<RequirementResponse>
   */
  update(id, data) {
    return api.put(`/requirements/${id}`, data);
  },

  /**
   * PATCH /requirements/{id}/decision
   * Body: DecisionRequest { status: "INHOUSE" | "OUTSOURCE", adminNotes? }
   *
   * ⚠️  Frontend was calling /requirements/{id}/status — FIXED to /decision
   *      Backend only accepts INHOUSE or OUTSOURCE (not PENDING) here.
   */
  makeDecision(id, status, adminNotes = "") {
    return api.patch(`/requirements/${id}/decision`, { status, adminNotes });
  },

  /**
   * DELETE /requirements/{id}
   */
  delete(id) {
    return api.delete(`/requirements/${id}`);
  },

  /**
   * GET /requirements/stats
   * Returns: ApiResponse<DashboardStatsResponse> {
   *   totalRequirements, pendingCount, inhouseCount, outsourceCount,
   *   totalUsers, clientCount, developerCount,
   *   byProjectType{}, byStatus{}
   * }
   */
  getStats() {
    return api.get("/requirements/stats");
  },

  // ── Future Scope (not yet in backend) ────────────────────────────────────
  // uploadFile:   POST /requirements/{id}/files
  // deleteFile:   DELETE /requirements/{id}/files/{fileId}
  // addComment:   POST /requirements/{id}/comments
  // getComments:  GET  /requirements/{id}/comments
  // deleteComment:DELETE /requirements/{id}/comments/{commentId}
  // assign:       PATCH /requirements/{id}/assign
  // exportReport: GET  /requirements/export
};
