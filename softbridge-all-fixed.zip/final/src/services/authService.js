import api from "./api";

/**
 * authService — maps to backend AuthController (/api/auth/*)
 *
 * Backend endpoints available:
 *   POST /auth/register
 *   POST /auth/login
 *   POST /auth/logout
 *
 * Profile endpoints are on UserController, not AuthController:
 *   GET    /users/me
 *   PUT    /users/me
 *   PATCH  /users/me/password
 *
 * NOTE: forgot-password, reset-password, refresh-token, verify-email
 *       are NOT implemented in the backend yet → marked as future scope.
 */
export const authService = {
  // ── Core Auth ────────────────────────────────────────────────────────────

  /**
   * POST /auth/login
   * Body: { email, password }
   * Returns: ApiResponse<AuthResponse> { accessToken, tokenType, expiresIn,
   *           userId, firstName, lastName, email, company, role, createdAt }
   */
  login(credentials) {
    return api.post("/auth/login", credentials);
  },

  /**
   * POST /auth/register
   * Body: { firstName, lastName, email, password, company?, phone?, role? }
   * Returns: ApiResponse<AuthResponse> — same as login
   */
  register(userData) {
    return api.post("/auth/register", userData);
  },

  /**
   * POST /auth/logout
   * JWT is stateless — server just returns 200.
   * Client must delete sb_token from localStorage.
   */
  logout() {
    return api.post("/auth/logout");
  },

  // ── Profile (UserController) ─────────────────────────────────────────────

  /**
   * GET /users/me
   * Returns current user's profile (UserResponse)
   */
  getProfile() {
    return api.get("/users/me");
  },

  /**
   * PUT /users/me
   * Body: { firstName?, lastName?, email?, company?, phone? }
   * Returns updated UserResponse
   */
  updateProfile(profileData) {
    return api.put("/users/me", profileData);
  },

  /**
   * PATCH /users/me/password
   * Body: { currentPassword, newPassword, confirmPassword }
   */
  changePassword(passwordData) {
    return api.patch("/users/me/password", passwordData);
  },

  // ── Future Scope (not yet in backend) ────────────────────────────────────
  // These will be added in a future sprint.

  // refreshToken()   → POST /auth/refresh
  // forgotPassword() → POST /auth/forgot-password
  // resetPassword()  → POST /auth/reset-password
  // verifyEmail()    → GET  /auth/verify-email
};
