import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useMemo,
} from "react";
import { authService } from "../services/authService";
import toast from "react-hot-toast";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser]     = useState(null);
  const [token, setToken]   = useState(localStorage.getItem("sb_token"));
  const [loading, setLoading] = useState(true);

  // ── Initialise from localStorage on first load ───────────────────────────
  useEffect(() => {
    try {
      const storedToken = localStorage.getItem("sb_token");
      const storedUser  = localStorage.getItem("sb_user");

      if (storedToken && storedUser) {
        setToken(storedToken);
        setUser(JSON.parse(storedUser));
      }
    } catch {
      localStorage.removeItem("sb_token");
      localStorage.removeItem("sb_user");
    } finally {
      setLoading(false);
    }
  }, []);

  // ── Login ────────────────────────────────────────────────────────────────
  const login = useCallback(async (email, password) => {
    try {
      const response = await authService.login({ email, password });

      /**
       * Backend returns ApiResponse<AuthResponse>:
       * {
       *   success: true,
       *   data: {
       *     accessToken, tokenType, expiresIn,
       *     userId, firstName, lastName, email, company, role, createdAt
       *   }
       * }
       *
       * ⚠️  Frontend was reading response.data.token and response.data.user
       *     FIXED: backend uses response.data.data.accessToken (wrapped in ApiResponse)
       */
      const authData = response.data.data;  // unwrap ApiResponse wrapper
      const jwtToken = authData.accessToken;

      // Build a user object from the flat AuthResponse fields
      const userObj = {
        id:        authData.userId,
        firstName: authData.firstName,
        lastName:  authData.lastName,
        fullName:  `${authData.firstName} ${authData.lastName}`,
        email:     authData.email,
        company:   authData.company,
        role:      authData.role,       // "CLIENT" | "ADMIN" | "DEVELOPER"
        createdAt: authData.createdAt,
      };

      localStorage.setItem("sb_token", jwtToken);
      localStorage.setItem("sb_user", JSON.stringify(userObj));

      setToken(jwtToken);
      setUser(userObj);

      toast.success(`Welcome back, ${userObj.firstName}!`);

      return { success: true, role: userObj.role };
    } catch (error) {
      const message =
        error?.response?.data?.message || "Invalid email or password";
      toast.error(message);
      return { success: false, error: message };
    }
  }, []);

  // ── Register ─────────────────────────────────────────────────────────────
  const register = useCallback(async (userData) => {
    try {
      /**
       * Backend RegisterRequest fields:
       *   firstName*, lastName*, email*, password*, company?, phone?, role?
       *
       * ⚠️  Backend does NOT allow self-registering as ADMIN.
       *     role defaults to CLIENT if not sent.
       */
      const response = await authService.register(userData);
      const authData = response.data.data;  // unwrap ApiResponse
      const jwtToken = authData.accessToken;

      const userObj = {
        id:        authData.userId,
        firstName: authData.firstName,
        lastName:  authData.lastName,
        fullName:  `${authData.firstName} ${authData.lastName}`,
        email:     authData.email,
        company:   authData.company,
        role:      authData.role,
        createdAt: authData.createdAt,
      };

      localStorage.setItem("sb_token", jwtToken);
      localStorage.setItem("sb_user", JSON.stringify(userObj));

      setToken(jwtToken);
      setUser(userObj);

      toast.success("Account created successfully!");

      return { success: true, role: userObj.role };
    } catch (error) {
      const message =
        error?.response?.data?.message || "Registration failed";
      toast.error(message);
      return { success: false, error: message };
    }
  }, []);

  // ── Logout ───────────────────────────────────────────────────────────────
  const logout = useCallback(async () => {
    try {
      // Tell backend (stateless JWT — just returns 200)
      await authService.logout();
    } catch {
      // Ignore errors — we always clear client-side session
    } finally {
      localStorage.removeItem("sb_token");
      localStorage.removeItem("sb_user");
      setUser(null);
      setToken(null);
      toast.success("Logged out successfully");
    }
  }, []);

  // ── Update user in context + storage ─────────────────────────────────────
  const updateUser = useCallback((updatedUser) => {
    setUser(updatedUser);
    localStorage.setItem("sb_user", JSON.stringify(updatedUser));
  }, []);

  // ── Context value ─────────────────────────────────────────────────────────
  const value = useMemo(
    () => ({
      user,
      token,
      loading,
      login,
      register,
      logout,
      updateUser,
      isAuthenticated: !!user,
      isAdmin:         user?.role === "ADMIN",
      isClient:        user?.role === "CLIENT",
      isDeveloper:     user?.role === "DEVELOPER",
      // SUPPORT role not in backend yet — kept for future use
      isSupport:       user?.role === "SUPPORT",
    }),
    [user, token, loading, login, register, logout, updateUser]
  );

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
};
